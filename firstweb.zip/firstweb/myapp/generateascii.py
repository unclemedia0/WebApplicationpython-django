#generateascii.py
import random
def GenerateToken(domain='http://localhost:8000/confirm/'):
	allcher = [ chr(i) for i in range(65,91)]
	allcher.extend([chr(i) for i in range(97,123)])
	allcher.extend([str(i) for i in range(10)])
	emailtoken = ''
	for i in range(40):
		emailtoken += random.choice(allcher)
	url = domain + emailtoken
	#print(url)
	return url 


gurl = GenerateToken('https://uncle-friut.com/confirm/')
print(gurl)
'''
 # ວິທີທີ່1
allcher = []
for i in range(65,91):
	allcher.append(chr(i))
for i in range(97,123):
	allcher.append(chr(i))
for i in range(10):
	allcher.append(str(i))
print(allcher)
print('--------')
 # ວິທີທີ່2
allcher = [ chr(i) for i in range(65,91)]
allcher.extend([chr(i) for i in range(97,123)])
allcher.extend([str(i) for i in range(10)])
print(allcher)
print('--------')
 # ວິທີທີ່3
import string 
allcher = list(string.ascii_letters)
allcher.extend([str(i) for i in range(10)])
print(allcher)
# ຜົນອອກເເບບດຽວກັນ
'''