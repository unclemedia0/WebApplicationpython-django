
from songline import Sendline
token = 'CQMz9zBbUm0DRhoxlXOgLzUNeRi9kNK8yZdWPFjpjc7'
messenger = Sendline(token)
#messenger.sendtext('ສະບາຍດີ SB IT POWER 1 ລາຍການ')
messenger.sticker(14,1,'ลูกค้าสั่งมา 100 บาท')
