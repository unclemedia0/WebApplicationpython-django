import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText

def sendthai(sendto,subj="ທົດສອບການສົ່ງເມວ",detail="ສະບາຍດີ!\nເຈົ້າສະບາຍດີບໍ?\n"):

	myemail = 'nouherdjango@gmail.com'
	mypassword = "dg/21nou"
	receiver = sendto

	msg = MIMEMultipart('alternative')
	msg['Subject'] = subj
	msg['From'] = 'SB IT POWER'
	msg['To'] = receiver
	text = detail

	part1 = MIMEText(text, 'plain')
	msg.attach(part1)

	s = smtplib.SMTP('smtp.gmail.com:587')
	s.ehlo()
	s.starttls()

	s.login(myemail, mypassword)
	s.sendmail(myemail, receiver.split(','), msg.as_string())
	s.quit()


###########Start sending#############
subject = 'ຢືນຍັນການສະມັກເວັບໄຊທ໌ການຊື້ອອນໄລນ໌'
newmember_name = 'ອຈ ນູເຮີ'
content = ''' 
ເພືອຄວາມປວດໄພຂອງການເຂົ້າໃຊ້ເວັບໄຊທ໌ກະລຸນາຢືນຢັນອີເມວ
'''
link = 'https://uncle-eng$ineer.com/cofirm/abcg1234jhipinnu'
msg = 'ສະບາຍດີເຈົ້າ {} \n\n {}\n Verify Link: {}'.format(newmember_name,content,link)
#msg = 'ສະບາຍດີເຈົ້າ {} \n\n Verify Link:{}'.format(newmember_name,content,link)

sendthai('nouherdjango@gmail.com',subject,msg)
