from django.urls import path
from .views import (
	Home, 
	About, 
	PageMobile,
	Detail,
	Contact,
	Dashboard_main,
	Graph ) 

urlpatterns = [
    path('', Home, name='home-page'),
    path('about/', About, name='mobile-about'),
    path('mobile/', PageMobile, name='mobile-all'),
    path('detail/<int:mobile_id>', Detail),
    path('contact/', Contact, name='contact-us'),
    path('dashboard/', Dashboard_main, name='dashboard-main'),
    path('graph/', Graph, name='graph')

]