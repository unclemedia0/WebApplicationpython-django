from django.db import models

# Create your models here.

class Allmobile(models.Model):

	mobile_name = models.CharField(max_length=100)
	mobile_price = models.CharField(max_length=100)
	mobile_detail = models.TextField(null=True)
	mobile_photo = models.ImageField(upload_to="gallery/%Y%m",blank=True, null=True)

	def __str__(self):
		return self.mobile_name

class ContactUs(models.Model):

	name = models.CharField(max_length=100)
	email = models.CharField(max_length=100)

	cat = [
		('shipping','การจัดส่ง'),
		('product','สินค้า'),
		('order','ออร์เดอร์')
	]

	category = models.CharField(
		max_length=100,
		choices=cat,
		default='shipping'
		)
	topic = models.CharField(max_length=100)
	detail = models.TextField(null=True)

	def __str__(self):
		return self.topic