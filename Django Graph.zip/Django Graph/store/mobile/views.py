from django.shortcuts import render, redirect
from django.http import HttpResponse
from .models import Allmobile, ContactUs
from django.contrib.auth.decorators import login_required

def Home(request):
	#return HttpResponse('<h1>Hello World</h1>')
	return render(request, 'mobile/home.html')

def About(request):
	#return HttpResponse('<h1>My name is Uncle Engineer</h1>')
	return render(request, 'mobile/about.html')

def PageMobile(request):
	#allmobile = ['Iphone','Huawei','Samsung']
	allmobile = Allmobile.objects.all()
	context = {'allmobile':allmobile}
	return render(request, 'mobile/mobile.html',context)

def Detail(request,mobile_id=1):
	try:
		onemobile = Allmobile.objects.get(id=mobile_id) #get single data
		context = {'onemobile':onemobile}
		return render(request, 'mobile/detail.html',context)
	except:
		return render(request, 'mobile/errorpage.html')

from .forms import contact_form

def Contact(request):

	if request.method == 'POST':
		form = contact_form(request.POST)
		if form.is_valid():
			form.save()
		return redirect('home-page')

	form = contact_form()
	context = {'form':form}

	return render(request, 'mobile/contact.html',context)

@login_required
def Dashboard_main(request):

	# Allmobile
	allmobile = Allmobile.objects.all()

	allprice = []

	for mb in allmobile:
		data = int(mb.mobile_price)
		allprice.append(data)

	print(allprice)
	print(allmobile)

	count = len(allmobile) #quantity of mobile
	total = sum(allprice)
	average = total / count
	mmax = max(allprice)
	mmin = min(allprice)


	print('COUNT: ',count)
	print('Allprice: ', total)
	print('Average: ', average)


	allcontact = ContactUs.objects.all()

	count_contact = len(allcontact)

	checkcat = [ ct.category for ct in allcontact]
	print('CHECK CAT', checkcat)

	cat = ['shipping','product','order']

	summarycat = [ [cc, checkcat.count(cc) ] for cc in cat ]
	#summarycat = [['shipping',2],['order',1]]

	#checkcat = ContactUs.objects.filter(category='shipping')

	context = {
		'mobile_count':count,
		'mobile_total':total,
		'mobile_average': average,
		'mobile_max':mmax,
		'mobile_min':mmin,
		'contact_count':count_contact,
		'contact_sum':summarycat

	}


	return render(request, 'mobile/db_main.html',context)


def Graph(request):

	allmobile = Allmobile.objects.all()

	all_price = []
	all_list = []

	for mb in allmobile:
		data = int(mb.mobile_price)
		data2 = mb.mobile_name
		all_price.append(data)
		all_list.append(data2)


	#mobile_list = ['Iphone','Huawei','Samsung','Nokia']
	#mobile_price = [100,500,200,400]
	mobile_list = all_list
	mobile_price = all_price

	context = {'mobile_list':str(mobile_list), 'mobile_price':mobile_price}
	return render(request, 'mobile/graph.html',context)
