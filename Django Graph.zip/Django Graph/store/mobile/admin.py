from django.contrib import admin
from .models import Allmobile, ContactUs

admin.site.register(Allmobile)
admin.site.register(ContactUs)
# Register your models here.
